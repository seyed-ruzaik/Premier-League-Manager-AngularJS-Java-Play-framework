export interface FootballClub {
  clubName: string;
  location: string;
  wins: number;
  draws: number;
  defeats: number;
  numOfGoalsReceived: number;
  numOfGoalsScored: number;
  numOfPoints: number;
  numOfMatches: number;
  numOfSeasons: number;
  diff: number;
}

