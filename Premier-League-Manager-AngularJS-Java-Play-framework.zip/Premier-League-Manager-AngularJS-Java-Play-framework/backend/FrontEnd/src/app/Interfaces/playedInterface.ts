export interface myResponse{
  status: boolean,
  response:string[]

}
