import {FootballClub} from './FootballClubInterface';


export interface response{

  status: boolean,
  response: FootballClub[]
}
