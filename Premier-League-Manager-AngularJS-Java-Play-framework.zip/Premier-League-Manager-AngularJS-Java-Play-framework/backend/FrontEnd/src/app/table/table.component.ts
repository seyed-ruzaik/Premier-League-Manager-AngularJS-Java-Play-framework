import {Component, OnInit, ViewChild} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';
import {response} from '../Interfaces/ResponseInterface';
import {Observable} from 'rxjs';
import {FootballClub} from '../Interfaces/FootballClubInterface';
import {myResponse} from "../Interfaces/playedInterface";


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
})
export class TableComponent implements  OnInit {
  // @ts-ignore
  b: myResponse;
  played: string[] = [];
  // @ts-ignore
  a: response;
  // @ts-ignore
  MyTable: FootballClub[];
  displayedColumns: string[] = ['clubName', 'location', 'wins', 'draws', 'defeats', 'numOfGoalsReceived',
    'numOfGoalsScored', 'numOfPoints', 'numOfMatches', 'numOfSeasons', 'diff'];

  // @ts-ignore
  @ViewChild(MatSort) sort: MatSort;
  dataSource = new MatTableDataSource<FootballClub>([]);


  constructor(private httpClient: HttpClient){
    this.getApi().subscribe(res => {
      this.a = res;
      this.MyTable = this.a.response;
      this.dataSource = new MatTableDataSource(this.MyTable);
      this.dataSource.sort = this.sort;
    });
  }
  ngOnInit(): void {

  }

  getApi(): Observable<response> {

    return this.httpClient.get<response>('http://localhost:9000/api');
  }

  gen():Observable<response>{

    return this.httpClient.get<response>('http://localhost:9000/api/matches/rand');
  }
  play():Observable<myResponse>{
    return this.httpClient.get<myResponse>('http://localhost:9000/api/matches');
  }

    onClick(){
      if (this.MyTable.length > 1) {
        this.gen().subscribe(resp => {
          this.a = resp;
          this.MyTable = this.a.response;
          this.dataSource = new MatTableDataSource(this.MyTable);
          this.dataSource.sort = this.sort;
          // console.log(this.MyTable)
          //   this.showPlayed();
          //   if (this.played.length > 0) {
          //     console.log(this.played[this.played.length - 1])
          //   }
        });
      }else {
        alert('Add At least 2 Teams To Generate');
      }
    }
onClick2(){
        this.play().subscribe(response=>{
          this.b = response;
          this.played = this.b.response;
          if (this.played.length > 0) {
            alert(this.played[this.played.length - 1])
          }else {
            alert('No Matches Played Yet!')
          }
        });
}

    // showPlayed(){
    //       this.play().subscribe(response=>{
    //         this.b = response;
    //         this.played = this.b.response;
    //       });
    //
    // }

}
