import {Component, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {myResponse} from "../Interfaces/playedInterface";
import {MatTableDataSource} from "@angular/material/table";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  // @ts-ignore
  b: myResponse;
  played: string[] = [];
  searched: string[] = [];
  // @ts-ignore
  check : string;
  displayedColumns: string[] = ['playedMatches'];
  // @ts-ignore
  public inputData: string = "";
  data = new MatTableDataSource<string>([]);

  constructor(private httpClient: HttpClient) {
    this.play().subscribe(response=>{
      this.b = response;
      this.played = this.b.response;
      this.searched = [];
      //  const str = this.played[0];
      // const my = str.match(/(\d{1,4}([.\-/])\d{1,2}([.\-/])\d{1,4})/g);
      // console.log(my)


    });

  }
  applyFilter(event: Event) {
    let filterValue = (event.target as HTMLInputElement).value;
    for (let i = 0; i < this.played.length; i++) {

      const str = this.played[i];
      const my = str.match(/(\d{1,4}([.\-/])\d{1,2}([.\-/])\d{1,4})/g);
      // @ts-ignore
      if (filterValue == my) {
        this.check = filterValue;
      }
    }

  }
  onClick(){
    for (let i = 0; i < this.played.length; i++) {

      const str = this.played[i];
      const my = str.match(/(\d{1,4}([.\-/])\d{1,2}([.\-/])\d{1,4})/g);

      // @ts-ignore
      if (this.check == my) {
        this.searched.push(str);
        this.data = new MatTableDataSource(this.searched);
      }

    }
    this.searched = []
    if (this.check == ''){
      this.data = new MatTableDataSource<string>([]);
    }

    this.inputData = "";
  }
  ngOnInit(): void {
  }

  play():Observable<myResponse>{
    return this.httpClient.get<myResponse>('http://localhost:9000/api/matches');
  }
}
