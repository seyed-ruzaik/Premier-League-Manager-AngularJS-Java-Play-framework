import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {HomeComponent} from './home/home.component';
import {TableComponent} from './table/table.component';
import {PlayedComponent} from './played/played.component';
import {SearchComponent} from './search/search.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'played', component: PlayedComponent},
  {path: 'search', component: SearchComponent},
  {path: 'table', component: TableComponent},
  {path: '', component: HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
