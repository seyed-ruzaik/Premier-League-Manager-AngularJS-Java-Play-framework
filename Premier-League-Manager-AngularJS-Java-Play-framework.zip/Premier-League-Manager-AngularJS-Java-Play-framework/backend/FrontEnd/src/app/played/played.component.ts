import {Component, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {myResponse} from "../Interfaces/playedInterface";
import {HttpClient} from "@angular/common/http";
import {MatTableDataSource} from "@angular/material/table";

@Component({
  selector: 'app-played',
  templateUrl: './played.component.html',
  styleUrls: ['./played.component.css']
})
export class PlayedComponent implements OnInit {
  // @ts-ignore
  b: myResponse;
  played: string[] = [];
  displayedColumns: string[] = ['playedMatches'];
  // @ts-ignore

  data = new MatTableDataSource<string>([]);

  constructor(private httpClient: HttpClient) {
    this.play().subscribe(response=>{
      this.b = response;
      this.played = this.b.response;
      this.data = new MatTableDataSource(this.played);
     //  const str = this.played[0];
     // const my = str.match(/(\d{1,4}([.\-/])\d{1,2}([.\-/])\d{1,4})/g);
     // console.log(my)


    });

  }
  // applyFilter(event: Event) {
  //   const filterValue = (event.target as HTMLInputElement).value;
  //   this.data = new MatTableDataSource(this.played);
  //   for (let i = 0; i < this.played.length; i++) {
  //
  //     const str = this.played[i];
  //     const my = str.match(/(\d{1,4}([.\-/])\d{1,2}([.\-/])\d{1,4})/g);
  //     if (filterValue == my) {
  //       console.log('hello')
  //     }else {
  //
  //     }
  //   }
  // }
  ngOnInit(): void {
  }

  play():Observable<myResponse>{
    return this.httpClient.get<myResponse>('http://localhost:9000/api/matches');
  }
}
